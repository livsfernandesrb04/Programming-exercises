#include <stdio.h>

int main() {

    int i; 

    for ( i = 101; i <= 110; i++)
    {
        printf("%d ", i);
    }
    return 0;
}